/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatappproject2;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Coordinates message-related user flows in QuickChat.
 *
 * This helper is responsible for:
 * - displaying the message menu,
 * - collecting and validating message input,
 * - tracking sent and stored messages,
 * - writing stored messages to JSON.
 *
 * @author Danielle Calldo
 */
public class MessageHelper {
    private final ArrayList<Message> messagesStored = new ArrayList<>();
    private final ArrayList<Message> messagesSent = new ArrayList<>();
    private final int allowedMessageChars = 250;
    private int numberOfMessages;

    /**
     * Returns how many messages were marked as sent in this session.
     *
     * @return sent messages count
     */
    public int getSentMessagesCount() {
        return this.messagesSent.size();
    }

    /**
     * Returns how many messages were stored for later sending.
     *
     * @return stored messages count
     */
    public int getStoredMessagesCount() {
        return this.messagesStored.size();
    }

    /**
     * Returns the number of messages the user asked to process.
     *
     * @return requested number of messages
     */
    public int getNumberOfMessages() {
        return this.numberOfMessages;
    }

    /**
     * Displays the QuickChat message menu and routes menu actions.
     *
     * Menu options allow users to:
     * - send messages,
     * - view a placeholder feature,
     * - quit the message area.
     */
    public void displayMessageMenu(){    
        do {
            String[] options = {"Send Messages", "Show recently sent messages - Coming Soon!", "Quit"};
            
            int userChoice = JOptionPane.showOptionDialog(
            null, 
            "QuickChat", 
            "Menu", 
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.PLAIN_MESSAGE, 
            null, 
            options, 
            options[0]
            );
            
            switch(userChoice){
                case 0:  // The user selects to send messages
                    while (true){
                        
                        // Ask how many messages they wish to send & store result
                        String input = JOptionPane.showInputDialog(null, "Enter the number of messages you want to process: ");
                        this.numberOfMessages = Integer.parseInt(input);
                        
                        // Check that the number entered is greater than 0
                        if (this.numberOfMessages > 0){
                            break;
                        } else {
                            JOptionPane.showMessageDialog(null, "Please enter a number greater than zero.");
                        }
                    }
                    
                    // Prompt for messages
                    this.promptForMessages();
                    
                    // Display total number of messages sent
                    JOptionPane.showMessageDialog(null, """
                                       Your total number of messages sent in this session is: """ + this.messagesSent.size());
                    
                    // Save all stored messages to json file
                    // If there are messages in the stored array
                    if (!this.messagesStored.isEmpty()){
                        CommonUtils.saveMessagesToJson(this.messagesStored);
                    }
                    break;
                    
                case 1:
                    JOptionPane.showMessageDialog(null, "This feature is still in development. Please try again.");
                    break;
                    
                case 2:
                    JOptionPane.showMessageDialog(null, "\nYou have exited the QuickChat.");
                    return;
            }
        }
        
        while (true);
                
    }
    
    /**
     * Prompts for message text and recipient details for each requested message.
     *
     * Each message is validated and then passed to {@code displayMessageOptions}
     * so the user can send, store, or delete it.
     */
    private void promptForMessages(){
        for (int i = 0; i < this.numberOfMessages; i++){
            String message;
            String cellRecipient;
            
            // Use while-loop to prompt for message
            // Continue to prompt until valid message entered
            while (true){
                message = (String) JOptionPane.showInputDialog(null, "Please enter a message less than 250 characters: ");
                
                // Check if the entered message exceeds the allowed char amount
                if (message.length() <= this.allowedMessageChars){
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Your message exceeded the character lenght. Please try again.");
                } 
            }
            
            // Prompt for a recipient phone number
            // Continue to prompt until valid recipient number
            while (true){
                cellRecipient = (String) JOptionPane.showInputDialog(null, "Please enter a recipient cellphone number. Ensure"
                        + "that the number is a valid 10 digit number with international country code: ");
                
                // Check if the entered recipient number is valid
                if (CommonUtils.checkCellphoneNumber(cellRecipient)){
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "The cellphone number entered is incorrect. Please try again.");
                } 
            }
            
            // Create message object and store in class array list
            // Store recipient number, message and current message number
            // Use i (index) + 1 because it starts from zero
            Message currentMessage = new Message(cellRecipient, message, i + 1);
            
            // Display message options to user, i.e. to send, save, or delete
            this.displayMessageOptions(currentMessage);
        }
    }
    
    /**
     * Displays actions for an individual message and updates in-memory lists
     * according to the selected option.
     *
     * @param message the message currently being processed
     */
    private void displayMessageOptions(Message message){
        while(true){
            String[] options = {"Send Message", "Store message to send later", "Delete the message"};
            
            int userChoice = JOptionPane.showOptionDialog(
            null, 
            "QuickChat", 
            "Menu", 
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.PLAIN_MESSAGE, 
            null, 
            options, 
            options[0]
            );
        
        switch(userChoice){
            case 0:
                JOptionPane.showMessageDialog(null, "\nMessage successfully sent!"
                        + "\nMessage ID: " + message.getMessageId()
                        + "\nMessage Hash: " + message.getMessageHash()
                        + "\nMessage Recipient: " + message.getRecipientNumber());
                
                // Store message in messages sent array
                this.messagesSent.add(message);
                return;
                
            case 1:
                // Store message in messages stored array
                JOptionPane.showMessageDialog(null, "\nYour message has been successfully stored.");
                this.messagesStored.add(message);
                return;
                
            case 2:
                JOptionPane.showMessageDialog(null, "\nMessage successfully deleted.");
                return;
                
            default:
                    // If the user selects and incorrect value
                    // then display message and return them to the main menu
                    JOptionPane.showMessageDialog(null, "\nIncorrect option selected. Please try again");
                    break;
            }
        }
    }
    
}
