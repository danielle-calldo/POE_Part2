/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatappproject2;

import javax.swing.JOptionPane;

/**
 *
 * @author Danielle Calldo
 */
public class ChatAppProject2 {

     public static void main(String[] args) {
        // Declare variables for scanner to read inputs and initialize login helper
        LoginHelper loginHelper = new LoginHelper();
        // Initialise message helper class to show QuickChat menu after login
        MessageHelper messageHelper = new MessageHelper();
        
        // Output a welcome message to users
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat");
        
        do {
            // This loop will continue to display the main menu
            // Until the user selects option 2 to exit the application
            String[] options = {"Login", "Register", "Exit"};
            
            int userChoice = JOptionPane.showOptionDialog(
            null, 
            "Main Menu - Select an Option", 
            "QuickChat Menu", 
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.PLAIN_MESSAGE, 
            null, 
            options, 
            options[0]
            );
            
            switch(userChoice){
                case 0:
                    // Use JOptionPane to get username & password
                    String usernameEntered = (String) JOptionPane.showInputDialog(null, "Please enter your username: ");
                    String passwordEntered = (String) JOptionPane.showInputDialog(null, "Please enter your password: ");
                    
                    // Validate the username and password for login
                    Boolean loginCorrect = loginHelper.checkValidLogin(usernameEntered, passwordEntered);
                    
                    // If login details are incorrect, display and message
                    // Then return the user to the main menu
                    if (!loginCorrect){
                        JOptionPane.showMessageDialog(null, "Login Failed. Select an option from the main menu to try again.");
                        break;
                    }
                    
                    // Display a welcome message when login details are correct
                    JOptionPane.showMessageDialog(null, "Login successful....Redirecting you to the chat app!");
                    
                    // Call Message Helper class to display QuickChat menu
                    messageHelper.displayMessageMenu();
                    return;
                    
                case 1:
                    // If a user selects option 2, run register flow
                    // Prompt, validate and store username, password and cellphone number
                    String username = promptForUsername(loginHelper);
                    // If username is set to exists, the user is already registered
                    if (username.equals("exists")){
                        break;
                    }
                    String password = promptForPassword(loginHelper);
                    String cellphoneNumber = promptForCellphoneNumber();
                    
                    // Once verified, store the user in the registered users array
                    loginHelper.registerVerifiedUser(username, password, cellphoneNumber);
                    // Display a success message and return to main menu for login
                    JOptionPane.showMessageDialog(null, "You are successfully registered! Login to continue.");
                    break;
                case 2:
                    // If the user selects 3, display message and exit program
                    JOptionPane.showMessageDialog(null, "Goodbye! See you next time.");
                    return;
                default:
                    // If the user selects and incorrect value
                    // then display message and return them to the main menu
                    JOptionPane.showMessageDialog(null, "Incorrect option selected. Please try again");
                    break;
            }
        } 
        while (true);
    }
    
    /**
     * This method uses a loop to prompt for a username until a valid username
     * is entered
     * 
     * @param helper
     * @return String username
     */
    private static String promptForUsername(LoginHelper helper){
        String username;
        while(true) {
            username = (String) JOptionPane.showInputDialog(null, "Please enter a username (5 chars max and an '_') ");
            
            Boolean alreadyRegistered = helper.checkForExistingUser(username);
            if (alreadyRegistered){
                JOptionPane.showMessageDialog(null, "The username entered already exists.");
                username = "exists";
                break;
            }
            
            Boolean validUsername = helper.checkUsername(username);
            if (validUsername){
                break;
            }
        }
        return username;
    }
    
    /**
     * This method prompts for a password until a valid input is entered
     * 
     * @param helper
     * @return String password
     */
    private static String promptForPassword(LoginHelper helper){
        String password;
        while(true) {
            password = (String) JOptionPane.showInputDialog(null, "Please enter a password (at least 8 characters, a capital letter"
                    + "a number and a special character): ");
            
            Boolean validPassword = helper.checkPasswordComplexity(password);
            if (validPassword){
                break;
            }
        }
        return password;
    }
    
    /**
     * This method prompts for a cellphone number until a valid input is entered
     * 
     * @return cellphone number
     */
    private static String promptForCellphoneNumber(){
        String cellphoneNumber;
        while(true) {
            cellphoneNumber = (String) JOptionPane.showInputDialog(null, "Please enter a valid 10 digit cellphone number for the "
                    + "account with the correct international country code: ");
            
            Boolean validCellphoneNumber = CommonUtils.checkCellphoneNumber(cellphoneNumber);
            if (validCellphoneNumber){
                break;
            }
        }
        return cellphoneNumber;
    }
}
