/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatappproject2;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Represents a single chat message captured in the application.
 *
 * Each message instance stores recipient details, message content,
 * an auto-generated numeric message ID, and a derived message hash.
 *
 * @author Danielle Calldo
 */
public class Message {
    private final long messageId;
    long smallestIdValue = 1_000_000_000L;
    long biggestIdValue = 9_999_999_999L; 
    private final String recipientNumber;
    private final int messageNumber;
    private final String messageStored;
    private final String messageHash;
    
    /**
     * Creates a new message and initializes all calculated values.
     *
     * @param recipient recipient cellphone number in international format
     * @param message message text content
     * @param number sequence number of this message in the current flow
     */
    public Message(String recipient, String message, int number) {
        this.messageId = generateMessageId();
        this.recipientNumber = recipient;
        this.messageStored = message;
        this.messageNumber = number;
        this.messageHash = generateMessageHash();
    }
    
    /**
     * Generates a random 10-digit message ID.
     *
     * @return randomly generated message ID
     */
    private long generateMessageId(){
        // Generates a random number between 1,000,000,000 and 9,999,999,999
        long randomNum = ThreadLocalRandom.current().nextLong(smallestIdValue, biggestIdValue + 1);
        return randomNum;
    }
    
    /**
     * Builds a compact hash using:
     * - the first digit of the generated message ID,
     * - the message number,
     * - the first and last words of the message content in uppercase.
     *
     * Format: <firstIdDigit>:<messageNumber>:<FIRST_WORD><LAST_WORD>
     *
     * @return generated message hash
     */
    private String generateMessageHash(){
        String messageIdStr = String.valueOf(this.messageId);
        String first2Numbers = messageIdStr.substring(0, 1);
        String[] messageWords = this.messageStored.split(" ");
        return first2Numbers + ":" + this.messageNumber + ":" 
                + messageWords[0].toUpperCase() + messageWords[messageWords.length - 1].toUpperCase();
    }
    
    /**
     * Returns the generated message ID.
     *
     * @return message ID
     */
    public long getMessageId() {
        return this.messageId;
    }
    
    /**
     * Returns the stored message text.
     *
     * @return message content
     */
    public String getMessageStored() {
        return this.messageStored;
    }
    
    /**
     * Returns the recipient cellphone number.
     *
     * @return recipient number
     */
    public String getRecipientNumber(){
        return this.recipientNumber;
    }
    
    /**
     * Returns the generated message hash.
     *
     * @return message hash
     */
    public String getMessageHash() {
        return this.messageHash;
    }
}
