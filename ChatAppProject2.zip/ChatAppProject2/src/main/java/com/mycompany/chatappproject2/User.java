/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatappproject2;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 *
 * @author Danielle Calldo
 */
public class User {
    // Set private variables for username and password
    private final String username;
    private final String password;
    private final String cellphoneNumber;
    private final byte[] salt;
    
    // Declare constructor for User object with username and password
    public User(String username, String password, String cellphoneNumber)
    {
        this.username = username;
        this.cellphoneNumber = cellphoneNumber;
        this.salt = generateSalt();
        this.password = this.hashString(password, "SHA-256");
    
    }
    
    // Expose getter method for username
    public String getUsername() {
        return username;
    }
    
    // Expose getter method for password
    public String getPassword() {
        return password;
    }
    
    // Expose getter method for cellphone number
    public String getCellphoneNumber(){
        return cellphoneNumber;
    }
    
    /**
     * Validates a username by comparing the received string to
     * the username of the User class
     * 
     * @param username
     * @return 
     */
    public boolean validateUsername(String username) {
        return this.username.equals(username);
    }
    
    /**
     * Validates a password by hashing the input and comparing it
     * to the stored password hash.
     *
     * @param passwordInput the password entered by the user
     * @return true if the password matches; otherwise false
     */
    public boolean validatePassword(String passwordInput) {
        String hashedInput = this.hashString(passwordInput, "SHA-256");
        return this.password.equals(hashedInput);
    }
    
    /**
     * This is a method to hash a user password for secure storage
     * It adds salt to the hashed password string for security
     * @param input
     * @param algorithm
     * @return String hashed password
     */
    private String hashString(String input, String algorithm) {
        try {
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            digest.update(this.salt);
            byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Generates random salt value to add to password hash
     * @return byte array
     */
    private byte[] generateSalt() {
        byte[] newSalt = new byte[16];
        SecureRandom random = new SecureRandom();
        random.nextBytes(newSalt);
        return newSalt;
    }
    
    /**
     * This method converts a bytes array to a hex string
     * @param bytes
     * @return String hexadecimal
     */
    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }
}
