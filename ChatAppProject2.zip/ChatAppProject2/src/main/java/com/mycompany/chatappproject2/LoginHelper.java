/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatappproject2;

import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 *
 * @author Danielle Calldo
 */
public class LoginHelper {
      // Set private variables for registered users array, password and phone pattern.
    private final ArrayList<User> registeredUsers = new ArrayList<>();
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$");
    
    /**
     * This method registers a verified user by adding a user object
     * to the registeredUsers array
     * 
     * @param name
     * @param password
     * @param cellphoneNumber 
     */
    public void registerVerifiedUser(String name, String password, String cellphoneNumber){ 
        User newVerifiedUser = new User(name, password, cellphoneNumber);
        this.registeredUsers.add(newVerifiedUser);
    }
    
    /**
     * This method checks whether a username already exists in registeredUsers.
     * 
     * @param username
     * @return Boolean
     */
    public boolean checkForExistingUser(String username){
        boolean userRegistered = registeredUsers.stream()
                .anyMatch(user -> user.getUsername().equals(username));     
        return userRegistered;
    }
    
    /**
     * This method checks whether a username & password is correct for login.
     * 
     * @param username
     * @param password
     * @return Boolean
     */
    public boolean checkValidLogin(String username, String password) {
    return registeredUsers.stream()
            .anyMatch(user -> user.getUsername().equals(username)
                    && user.validatePassword(password));
    }
    
    /**
     * This method validates an entered username against register requirements.
     * 
     * @param username
     * @return Boolean
     */
    public boolean checkUsername(String username){
        boolean validUsername = username.contains("_") && username.length() <= 5;
        if (validUsername) {
            System.out.println("Username successfully captured.");
        } 
        else {
            System.out.println("Username is not correctly formatted.");
        }
        
        return validUsername;
    }
    
    /**
     * This method checks the entered password against register requirements.
     * 
     * @param password
     * @return Boolean
     */
    public boolean checkPasswordComplexity(String password){
        boolean validPassword = PASSWORD_PATTERN.matcher(password).matches();
        if (validPassword){
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password is not correctly formatted.");
        }
        
        return validPassword;
    }
    
}
