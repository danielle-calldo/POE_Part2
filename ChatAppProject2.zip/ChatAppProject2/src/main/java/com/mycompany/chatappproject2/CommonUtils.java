package com.mycompany.chatappproject2;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * Shared utility methods used across QuickChat classes.
 */
public final class CommonUtils {

    private static final Pattern SA_PHONE_PATTERN = Pattern.compile("^\\+27\\d{9}$");

    private CommonUtils() {
        // Utility class; prevent instantiation.
    }

    /**
     * Validates a South African cellphone number with international country code.
     *
     * @param cellphoneNumber cellphone number input
     * @return true if the number matches +27 followed by 9 digits; otherwise false
     */
    public static boolean checkCellphoneNumber(String cellphoneNumber) {
        boolean validCellphoneNumber = SA_PHONE_PATTERN.matcher(cellphoneNumber).matches();
        if (validCellphoneNumber) {
            System.out.println("Cellphone number successfully added.");
        } else {
            System.out.println("""
                               Cell phone number incorrectly formatted or does
                               not contain international code.
                               """);
        }

        return validCellphoneNumber;
    }

    /**
     * Writes provided messages to savedMessages.json as a JSON array.
     *
     * @param messagesToStore list of messages to persist
     */
    public static void saveMessagesToJson(ArrayList<Message> messagesToStore) {
        JSONArray jsonArray = new JSONArray();

        for (Message message : messagesToStore) {
            JSONObject obj = new JSONObject();
            obj.put("messageId", message.getMessageId());
            obj.put("messageHash", message.getMessageHash());
            obj.put("messageContent", message.getMessageStored());
            obj.put("messageRecipient", message.getRecipientNumber());
            jsonArray.add(obj);
        }

        try (FileWriter file = new FileWriter("savedMessages.json")) {
            file.write(jsonArray.toJSONString());
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
