package com.mycompany.chatappproject2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class MessageTest {

    private static final String VALID_RECIPIENT = "+27821234567";

    @Test
    public void givenValidConstructorInputs_whenMessageCreated_shouldSetRecipientAndStoredMessage() {
        // Arrange
        String recipient = VALID_RECIPIENT;
        String messageText = "Hello there";
        int messageNumber = 1;

        // Act
        Message message = new Message(recipient, messageText, messageNumber);

        // Assert
        assertEquals(recipient, message.getRecipientNumber());
        assertEquals(messageText, message.getMessageStored());
    }

    @Test
    public void givenMessageCreated_whenGettingMessageId_shouldReturnIdWithinExpectedRange() {
        // Arrange
        Message message = new Message(VALID_RECIPIENT, "Hello there", 1);

        // Act
        long messageId = message.getMessageId();

        // Assert
        assertTrue(messageId >= 1_000_000_000L);
        assertTrue(messageId <= 9_999_999_999L);
    }

    @Test
    public void givenMultiWordMessage_whenMessageCreated_shouldBuildExpectedMessageHash() {
        // Arrange
        String messageText = "hello from quick chat";
        int messageNumber = 3;

        // Act
        Message message = new Message(VALID_RECIPIENT, messageText, messageNumber);

        // Assert
        String firstIdDigit = String.valueOf(message.getMessageId()).substring(0, 1);
        String expectedHash = firstIdDigit + ":" + messageNumber + ":" + "HELLO" + "CHAT";
        assertEquals(expectedHash, message.getMessageHash());
    }

    @Test
    public void givenSingleWordMessage_whenMessageCreated_shouldBuildExpectedMessageHashWithRepeatedWord() {
        // Arrange
        String messageText = "ping";
        int messageNumber = 2;

        // Act
        Message message = new Message(VALID_RECIPIENT, messageText, messageNumber);

        // Assert
        String firstIdDigit = String.valueOf(message.getMessageId()).substring(0, 1);
        String expectedHash = firstIdDigit + ":" + messageNumber + ":" + "PING" + "PING";
        assertEquals(expectedHash, message.getMessageHash());
    }
}
