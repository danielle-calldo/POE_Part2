package com.mycompany.chatappproject2;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.lang.reflect.Field;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MessageHelperTest {

    private static final Path SAVED_MESSAGES_FILE = Path.of("savedMessages.json");

    @BeforeEach
    public void setUp() throws IOException {
        Files.deleteIfExists(SAVED_MESSAGES_FILE);
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(SAVED_MESSAGES_FILE);
    }

    @Test
    public void givenTwoSentMessagesInState_whenReadingSentCount_shouldReturnTwo() throws Exception {
        // Arrange
        MessageHelper helper = new MessageHelper();
        ArrayList<Message> sentMessages = getInternalMessageList(helper, "messagesSent");
        sentMessages.add(new Message("+27821234567", "first sent message", 1));
        sentMessages.add(new Message("+27821234568", "second sent message", 2));

        // Act
        int sentCount = helper.getSentMessagesCount();

        // Assert
        assertEquals(2, sentCount);
    }

    @Test
    public void givenStoredMessages_whenSavingToJson_shouldPersistSavedMessagesToFile() throws Exception {
        // Arrange
        MessageHelper helper = new MessageHelper();
        ArrayList<Message> storedMessages = getInternalMessageList(helper, "messagesStored");
        storedMessages.add(new Message("+27821234567", "store this message", 1));

        // Act
        CommonUtils.saveMessagesToJson(storedMessages);

        // Assert
        assertEquals(0, helper.getSentMessagesCount());
        assertEquals(1, helper.getStoredMessagesCount());
        assertTrue(Files.exists(SAVED_MESSAGES_FILE));

        String savedJson = Files.readString(SAVED_MESSAGES_FILE, StandardCharsets.UTF_8);
        JSONArray savedArray = parseSavedJson(savedJson);
        assertEquals(1, savedArray.size());

        JSONObject firstMessage = (JSONObject) savedArray.get(0);
        assertEquals("store this message", firstMessage.get("messageContent"));
        assertEquals("+27821234567", firstMessage.get("messageRecipient"));
    }

    @Test
    public void givenTotalSentAndStoredCounts_whenCalculatingDeletedCount_shouldReturnExpectedDeletedCount() throws Exception {
        // Arrange
        MessageHelper helper = new MessageHelper();
        ArrayList<Message> sentMessages = getInternalMessageList(helper, "messagesSent");
        ArrayList<Message> storedMessages = getInternalMessageList(helper, "messagesStored");
        sentMessages.add(new Message("+27821234567", "message one", 1));
        storedMessages.add(new Message("+27821234568", "message two", 2));
        setNumberOfMessages(helper, 3);

        // Act
        int totalMessages = helper.getNumberOfMessages();
        int sentCount = helper.getSentMessagesCount();
        int storedCount = helper.getStoredMessagesCount();
        int deletedCount = totalMessages - (sentCount + storedCount);

        // Assert
        assertEquals(1, sentCount);
        assertEquals(1, storedCount);
        assertEquals(1, deletedCount);
    }

    private JSONArray parseSavedJson(String savedJson) throws ParseException {
        return (JSONArray) new JSONParser().parse(savedJson);
    }

    @SuppressWarnings("unchecked")
    private ArrayList<Message> getInternalMessageList(MessageHelper helper, String fieldName) throws Exception {
        Field field = MessageHelper.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return (ArrayList<Message>) field.get(helper);
    }

    private void setNumberOfMessages(MessageHelper helper, int value) throws Exception {
        Field numberField = MessageHelper.class.getDeclaredField("numberOfMessages");
        numberField.setAccessible(true);
        numberField.setInt(helper, value);
    }
}
