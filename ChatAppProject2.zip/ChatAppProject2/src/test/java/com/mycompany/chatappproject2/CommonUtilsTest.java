package com.mycompany.chatappproject2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CommonUtilsTest {

    @Test
    public void givenValidCellphoneNumber_whenCheckingCellphoneNumber_shouldReturnTrue() {
        // Arrange
        String cellphoneNumber = "+27821234567";

        // Act
        boolean result = CommonUtils.checkCellphoneNumber(cellphoneNumber);

        // Assert
        assertTrue(result);
    }

    @Test
    public void givenCellphoneWithoutCountryCode_whenCheckingCellphoneNumber_shouldReturnFalse() {
        // Arrange
        String cellphoneNumber = "0821234567";

        // Act
        boolean result = CommonUtils.checkCellphoneNumber(cellphoneNumber);

        // Assert
        assertFalse(result);
    }
}
