/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatappproject2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Danielle Calldo
 */
public class LoginTest {

    private LoginHelper loginHelper;
    
    @BeforeEach
    public void setUp() {
        this.loginHelper = new LoginHelper();
    }

    @Test
    public void givenValidUsername_whenCheckingUsername_shouldReturnTrue() {
        // Arrange
        String username = "ab_1";

        // Act
        boolean result = this.loginHelper.checkUsername(username);

        // Assert
        assertTrue(result);
    }

    @Test
    public void givenUsernameWithoutUnderscore_whenCheckingUsername_shouldReturnFalse() {
        // Arrange
        String username = "abcd";

        // Act
        boolean result = this.loginHelper.checkUsername(username);

        // Assert
        assertFalse(result);
    }

    @Test
    public void givenUsernameLongerThanFiveCharacters_whenCheckingUsername_shouldReturnFalse() {
        // Arrange
        String username = "abc_12";

        // Act
        boolean result = this.loginHelper.checkUsername(username);

        // Assert
        assertFalse(result);
    }

    @Test
    public void givenValidPassword_whenCheckingPasswordComplexity_shouldReturnTrue() {
        // Arrange
        String password = "Password1!";

        // Act
        boolean result = this.loginHelper.checkPasswordComplexity(password);

        // Assert
        assertTrue(result);
    }

    @Test
    public void givenPasswordWithoutUppercase_whenCheckingPasswordComplexity_shouldReturnFalse() {
        // Arrange
        String password = "password1!";

        // Act
        boolean result = this.loginHelper.checkPasswordComplexity(password);

        // Assert
        assertFalse(result);
    }

    @Test
    public void givenPasswordWithoutNumber_whenCheckingPasswordComplexity_shouldReturnFalse() {
        // Arrange
        String password = "Password!";

        // Act
        boolean result = this.loginHelper.checkPasswordComplexity(password);

        // Assert
        assertFalse(result);
    }

    @Test
    public void givenPasswordWithoutSpecialCharacter_whenCheckingPasswordComplexity_shouldReturnFalse() {
        // Arrange
        String password = "Password1";

        // Act
        boolean result = this.loginHelper.checkPasswordComplexity(password);

        // Assert
        assertFalse(result);
    }

    @Test
    public void givenRegisteredUser_whenCheckingForExistingUser_shouldReturnTrue() {
        // Arrange
        String username = "ab_1";
        String password = "Password1!";
        String cellphoneNumber = "+27821234567";
        this.loginHelper.registerVerifiedUser(username, password, cellphoneNumber);

        // Act
        boolean result = this.loginHelper.checkForExistingUser(username);

        // Assert
        assertTrue(result);
    }

    @Test
    public void givenUnregisteredUser_whenCheckingForExistingUser_shouldReturnFalse() {
        // Arrange
        String username = "ab_1";

        // Act
        boolean result = this.loginHelper.checkForExistingUser(username);

        // Assert
        assertFalse(result);
    }

    @Test
    public void givenRegisteredUserWithCorrectPassword_whenCheckingValidLogin_shouldReturnTrue() {
        // Arrange
        String username = "ab_1";
        String password = "Password1!";
        String cellphoneNumber = "+27821234567";
        this.loginHelper.registerVerifiedUser(username, password, cellphoneNumber);

        // Act
        boolean result = this.loginHelper.checkValidLogin(username, password);

        // Assert
        assertTrue(result);
    }

    @Test
    public void givenRegisteredUserWithWrongPassword_whenCheckingValidLogin_shouldReturnFalse() {
        // Arrange
        String username = "ab_1";
        String password = "Password1!";
        String wrongPassword = "Password2!";
        String cellphoneNumber = "+27821234567";
        this.loginHelper.registerVerifiedUser(username, password, cellphoneNumber);

        // Act
        boolean result = this.loginHelper.checkValidLogin(username, wrongPassword);

        // Assert
        assertFalse(result);
    }

    @Test
    public void givenWrongUsernameWithCorrectPassword_whenCheckingValidLogin_shouldReturnFalse() {
        // Arrange
        String username = "ab_1";
        String wrongUsername = "xy_1";
        String password = "Password1!";
        String cellphoneNumber = "+27821234567";
        this.loginHelper.registerVerifiedUser(username, password, cellphoneNumber);

        // Act
        boolean result = this.loginHelper.checkValidLogin(wrongUsername, password);

        // Assert
        assertFalse(result);
    }
    
}
