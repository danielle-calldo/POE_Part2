/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatappproject2;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Danielle Calldo
 */
public class TestUser {
    private static User testUser;
    
    @BeforeAll
    public static void setUpClass() {
        String validUsername = "jD_5!";
        String validPassword = "passTest77@!";
        String validCellphoneNumber = "+27849504938";
        testUser = new User(validUsername, validPassword, validCellphoneNumber);
    }
    
    @Test
    public void givenMatchingUsername_whenValidateUsernameIsCalled_ReturnsTrue() {
        // Arrange
        String usernameToCheck = "jD_5!";
        
        // Act
        boolean result = testUser.validateUsername(usernameToCheck);
        
        // Assert
        assertTrue(result);
    
    }
    
    @Test
    public void givenNonMatchingUsername_whenValidateUsernameIsCalled_ReturnsFalse() {
        // Arrange
        String usernameToCheck = "jade_5";
        
        // Act
        boolean result = testUser.validateUsername(usernameToCheck);
        
        // Assert
        assertFalse(result);
    
    }
    
    @Test
    public void givenMatchingPassword_whenValidatePasswordIsCalled_ReturnsTrue() {
        // Arrange
        String passwordToCheck = "passTest77@!";
        
        // Act
        boolean result = testUser.validatePassword(passwordToCheck);
        
        // Assert
        assertTrue(result);
    
    }
    
    @Test
    public void givenNonMatchingPassword_whenValidatePasswordIsCalled_ReturnsFalse() {
        // Arrange
        String passwordToCheck = "password";
        
        // Act
        boolean result = testUser.validatePassword(passwordToCheck);
        
        // Assert
        assertFalse(result);
    
    }
    
     @Test
    public void givenExpectedUsername_whenGetUsernameIsCalled_ExpectedEqualsResult() {
        // Arrange
        String expectedUsername = "jD_5!";
        
        // Act
        String result = testUser.getUsername();
        
        // Assert
        assertEquals(expectedUsername, result);
    
    }
}
